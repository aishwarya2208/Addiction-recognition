# Tarp
In this project, we will develop a mechanism to search through a dataset of images with and classify them on the basis of their facial features and analyze the possibility of addiction towards alcohol or drugs
# Installation #
pip install sklearn.preprocessing\
pip install sklearn\
pip install sklearn.model_selection\
pip install sklearn.linear_model \
pip install pandas\
pip install numpy\
pip install seaborn\
pip install matplotlib.pyplot\
pip install sklearn.metrics\
pip install sklearn.preprocessing \
pip install sklearn.decomposition\
pip install sklearn.svm
# Software Details #
This Code can be run on any Python compiler
## Python ##
Python is an interpreted, high-level, general-purpose programming language
## Jupyter Notebook ##
Jupyter is a nonprofit organization created to "develop open-source software, open-standards, and services for interactive computing across dozens of programming languages". Spun-off from IPython in 2014 by Fernando Pérez, Project Jupyter supports execution environments in several dozen languages.
## MATLAB ##
MATLAB is a multi-paradigm numerical computing environment and proprietary programming language developed by MathWorks.
